module com.example.demo {
    requires javafx.controls;
    requires java.sql;
    exports com.example.demo;
}