package com.example.demo;
import javafx.application.Application;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Stage;
import java.sql.SQLException;

public class App extends Application {
    static void main(String[] args) {
        launch();
    }
    @Override
    public void start(Stage stage) throws SQLException {
        var data = new FilteredList<>(Hadith.getHadiths());
        var list = new ListView<>(data);
        var search = new TextField();
        list.setCellFactory(view -> new CellTemplate(search));
        var label = new Label(String.format("%,d", data.size()));
        search.textProperty().addListener(o -> {
            var filter = search.getText().toLowerCase();
            if (filter.length() == 0) data.setPredicate(hadith -> true);
            else data.setPredicate(hadith -> hadith.content.toLowerCase().contains(filter));
            label.setText(String.format("%,d", data.size()));
        });
        var box = new HBox();
        HBox.setHgrow(search, Priority.ALWAYS);
        search.setPromptText("Search");
        label.setPadding(new Insets(5));
        box.getChildren().addAll(search, label);
        var content = new BorderPane();
        content.setTop(box);
        content.setCenter(list);
        BorderPane.setMargin(list, new Insets(5));
        BorderPane.setMargin(box, new Insets(5));
        var scene = new Scene(content, 320, 240);
        stage.setTitle("ListView Test");
        stage.setScene(scene);
        stage.show();
    }
}