package com.example.demo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Hadith {
    public String hadithNo;
    public String chapterNo;
    public String volume;
    public String chapterName;
    public String narrator;
    public String content;

    public static ObservableList<Hadith> getHadiths() throws SQLException {
        ObservableList<Hadith> data = FXCollections.observableArrayList();
        var con = DriverManager.getConnection("jdbc:sqlite:bukhari.db");
        var result = con.createStatement().executeQuery("SELECT * FROM Hadith");
        while (result.next()) {
            data.add(new Hadith(){{
                hadithNo = result.getString(1);
                volume = result.getString(2);
                chapterNo = result.getString(3);
                chapterName = result.getString(4);
                narrator = result.getString(5);
                content = result.getString(7);
            }});
        }
        con.close();
        return data;
    }
}
