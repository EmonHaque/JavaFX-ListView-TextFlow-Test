package com.example.demo;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class CellTemplate extends ListCell<Hadith> {
    final TextField query;
    public CellTemplate(TextField query){
        this.query = query;
    }
    @Override
    protected void updateItem(Hadith item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setGraphic(null);
            setText(null);
        }
        else{
            setPrefWidth(0);
            var box = new VBox();
            var title = new HBox();
            var leftText = new Text("Hadith No. " + item.hadithNo + " | " + "Chapter " + item.chapterNo + " - " + item.chapterName + " | ");
            leftText.setFont(Font.font("Helvetica", FontWeight.BOLD, 12));
            var midText = new Text("by: " + item.narrator);
            midText.setFont(Font.font("Helvetica", FontPosture.ITALIC, 12));
            var rightText = new Text("Volume: " + item.volume);
            rightText.setFont(Font.font("Helvetica", FontWeight.BOLD, 12));
            var spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            title.getChildren().addAll(leftText, midText, spacer, rightText);

            box.getChildren().add(new Separator());
            box.getChildren().add(title);
            box.getChildren().add(new Separator());
            if (!query.getText().isEmpty() && item.content.toLowerCase().contains(query.getText().toLowerCase())) {
                box.getChildren().add(highlight(item.content, query.getText().toLowerCase()));
            } else {
                box.getChildren().add(new TextFlow(new Text(item.content)));
            }
            setGraphic(box);
            setText(null);
        }
    }
    TextFlow highlight(String original, String filter) {
        var flow = new TextFlow();
        int index = 0;
        int filterLength = filter.length();
        var text = original.toLowerCase();
        for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)){
            flow.getChildren().add(new Text(original.substring(index, i)));
            var match = new Text(original.substring(i, i + filterLength));
            match.setFill(Color.BLUE);
            match.setFont(Font.font("Helvetica", FontWeight.BOLD, 12));
            match.setUnderline(true);
            flow.getChildren().add(match);
            index = i + filterLength;
        }
        if (index < text.length()) flow.getChildren().add(new Text(original.substring(index)));
        return flow;
    }
}
